
"use strict";

let Objs = require('./Objs.js')

module.exports = {
  Objs: Objs,
};
