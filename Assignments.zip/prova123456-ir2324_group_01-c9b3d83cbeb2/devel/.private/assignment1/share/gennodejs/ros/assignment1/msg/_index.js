
"use strict";

let coords = require('./coords.js');
let ScanResult = require('./ScanResult.js');
let ScanActionFeedback = require('./ScanActionFeedback.js');
let ScanActionGoal = require('./ScanActionGoal.js');
let ScanActionResult = require('./ScanActionResult.js');
let ScanFeedback = require('./ScanFeedback.js');
let ScanGoal = require('./ScanGoal.js');
let ScanAction = require('./ScanAction.js');

module.exports = {
  coords: coords,
  ScanResult: ScanResult,
  ScanActionFeedback: ScanActionFeedback,
  ScanActionGoal: ScanActionGoal,
  ScanActionResult: ScanActionResult,
  ScanFeedback: ScanFeedback,
  ScanGoal: ScanGoal,
  ScanAction: ScanAction,
};
