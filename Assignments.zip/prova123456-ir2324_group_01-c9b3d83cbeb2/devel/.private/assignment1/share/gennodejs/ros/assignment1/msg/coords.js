// Auto-generated. Do not edit!

// (in-package assignment1.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class coords {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.x_out = null;
      this.y_out = null;
      this.z_out = null;
    }
    else {
      if (initObj.hasOwnProperty('x_out')) {
        this.x_out = initObj.x_out
      }
      else {
        this.x_out = 0.0;
      }
      if (initObj.hasOwnProperty('y_out')) {
        this.y_out = initObj.y_out
      }
      else {
        this.y_out = 0.0;
      }
      if (initObj.hasOwnProperty('z_out')) {
        this.z_out = initObj.z_out
      }
      else {
        this.z_out = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type coords
    // Serialize message field [x_out]
    bufferOffset = _serializer.float32(obj.x_out, buffer, bufferOffset);
    // Serialize message field [y_out]
    bufferOffset = _serializer.float32(obj.y_out, buffer, bufferOffset);
    // Serialize message field [z_out]
    bufferOffset = _serializer.float32(obj.z_out, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type coords
    let len;
    let data = new coords(null);
    // Deserialize message field [x_out]
    data.x_out = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [y_out]
    data.y_out = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [z_out]
    data.z_out = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'assignment1/coords';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '644bea9f9b8b24e14c1659f098c30ba8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 x_out
    float32 y_out
    float32 z_out
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new coords(null);
    if (msg.x_out !== undefined) {
      resolved.x_out = msg.x_out;
    }
    else {
      resolved.x_out = 0.0
    }

    if (msg.y_out !== undefined) {
      resolved.y_out = msg.y_out;
    }
    else {
      resolved.y_out = 0.0
    }

    if (msg.z_out !== undefined) {
      resolved.z_out = msg.z_out;
    }
    else {
      resolved.z_out = 0.0
    }

    return resolved;
    }
};

module.exports = coords;
